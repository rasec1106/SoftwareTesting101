package pe.edu.cibertec.CL1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cl1Application {

	public static void main(String[] args) {
		SpringApplication.run(Cl1Application.class, args);
	}

}
