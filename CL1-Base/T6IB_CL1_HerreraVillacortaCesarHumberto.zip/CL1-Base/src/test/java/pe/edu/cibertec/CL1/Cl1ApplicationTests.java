package pe.edu.cibertec.CL1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cl1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
